import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Enums
export const userRoleEnum = pgEnum("user_role", ["student", "faculty", "recruiter", "admin"]);
export const certificateStatusEnum = pgEnum("certificate_status", ["pending", "approved", "rejected"]);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  role: userRoleEnum("role").notNull().default("student"),
  profileImageUrl: varchar("profile_image_url"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Certificates table
export const certificates = pgTable("certificates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  institution: varchar("institution").notNull(),
  description: text("description"),
  fileName: varchar("file_name").notNull(),
  filePath: varchar("file_path").notNull(),
  fileSize: integer("file_size").notNull(),
  mimeType: varchar("mime_type").notNull(),
  status: certificateStatusEnum("status").default("pending"),
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewNotes: text("review_notes"),
  blockchainHash: varchar("blockchain_hash"),
  qrCode: text("qr_code"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Blockchain table
export const blockchain = pgTable("blockchain", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  blockNumber: integer("block_number").notNull(),
  hash: varchar("hash").notNull().unique(),
  previousHash: varchar("previous_hash"),
  data: text("data").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  nonce: integer("nonce").notNull(),
});

// Portfolio views table
export const portfolioViews = pgTable("portfolio_views", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  viewerIp: varchar("viewer_ip"),
  viewedAt: timestamp("viewed_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  certificates: many(certificates),
  portfolioViews: many(portfolioViews),
}));

export const certificatesRelations = relations(certificates, ({ one }) => ({
  user: one(users, {
    fields: [certificates.userId],
    references: [users.id],
  }),
  reviewer: one(users, {
    fields: [certificates.reviewedBy],
    references: [users.id],
  }),
}));

export const portfolioViewsRelations = relations(portfolioViews, ({ one }) => ({
  user: one(users, {
    fields: [portfolioViews.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  firstName: true,
  lastName: true,
  role: true,
});

export const insertCertificateSchema = createInsertSchema(certificates).pick({
  title: true,
  institution: true,
  description: true,
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCertificate = z.infer<typeof insertCertificateSchema>;
export type LoginUser = z.infer<typeof loginSchema>;
export type User = typeof users.$inferSelect;
export type Certificate = typeof certificates.$inferSelect;
export type BlockchainRecord = typeof blockchain.$inferSelect;
export type PortfolioView = typeof portfolioViews.$inferSelect;



