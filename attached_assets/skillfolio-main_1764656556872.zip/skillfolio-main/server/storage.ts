import { 
  users, 
  certificates, 
  blockchain, 
  portfolioViews,
  type User, 
  type InsertUser, 
  type Certificate,
  type InsertCertificate,
  type BlockchainRecord,
  type PortfolioView
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, count, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  getUsersByRole(role: string): Promise<User[]>;
  
  // Certificate operations
  getCertificate(id: string): Promise<Certificate | undefined>;
  getCertificatesByUser(userId: string): Promise<Certificate[]>;
  getCertificatesByStatus(status: string): Promise<Certificate[]>;
  createCertificate(certificate: Omit<Certificate, 'id' | 'createdAt' | 'updatedAt'>): Promise<Certificate>;
  updateCertificate(id: string, updates: Partial<Certificate>): Promise<Certificate>;
  
  // Blockchain operations
  addBlockchainRecord(record: Omit<BlockchainRecord, 'id' | 'timestamp'>): Promise<BlockchainRecord>;
  getBlockchainRecord(hash: string): Promise<BlockchainRecord | undefined>;
  getLatestBlock(): Promise<BlockchainRecord | undefined>;
  
  // Portfolio operations
  addPortfolioView(view: Omit<PortfolioView, 'id' | 'viewedAt'>): Promise<PortfolioView>;
  getPortfolioViews(userId: string): Promise<number>;
  
  // Analytics
  getUserStats(): Promise<{ total: number; students: number; faculty: number; recruiters: number; admins: number; }>;
  getCertificateStats(): Promise<{ total: number; pending: number; approved: number; rejected: number; }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role as any));
  }

  // Certificate operations
  async getCertificate(id: string): Promise<Certificate | undefined> {
    const [certificate] = await db.select().from(certificates).where(eq(certificates.id, id));
    return certificate;
  }

  async getCertificatesByUser(userId: string): Promise<Certificate[]> {
    return await db
      .select()
      .from(certificates)
      .where(eq(certificates.userId, userId))
      .orderBy(desc(certificates.createdAt));
  }

  async getCertificatesByStatus(status: string): Promise<Certificate[]> {
    return await db
      .select()
      .from(certificates)
      .where(eq(certificates.status, status as any))
      .orderBy(desc(certificates.createdAt));
  }

  async createCertificate(certificate: Omit<Certificate, 'id' | 'createdAt' | 'updatedAt'>): Promise<Certificate> {
    const [newCertificate] = await db
      .insert(certificates)
      .values({
        ...certificate,
        updatedAt: new Date(),
      })
      .returning();
    return newCertificate;
  }

  async updateCertificate(id: string, updates: Partial<Certificate>): Promise<Certificate> {
    const [certificate] = await db
      .update(certificates)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(certificates.id, id))
      .returning();
    return certificate;
  }

  // Blockchain operations
  async addBlockchainRecord(record: Omit<BlockchainRecord, 'id' | 'timestamp'>): Promise<BlockchainRecord> {
    const [blockchainRecord] = await db
      .insert(blockchain)
      .values(record)
      .returning();
    return blockchainRecord;
  }

  async getBlockchainRecord(hash: string): Promise<BlockchainRecord | undefined> {
    const [record] = await db.select().from(blockchain).where(eq(blockchain.hash, hash));
    return record;
  }

  async getLatestBlock(): Promise<BlockchainRecord | undefined> {
    const [record] = await db
      .select()
      .from(blockchain)
      .orderBy(desc(blockchain.blockNumber))
      .limit(1);
    return record;
  }

  // Portfolio operations
  async addPortfolioView(view: Omit<PortfolioView, 'id' | 'viewedAt'>): Promise<PortfolioView> {
    const [portfolioView] = await db
      .insert(portfolioViews)
      .values(view)
      .returning();
    return portfolioView;
  }

  async getPortfolioViews(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(portfolioViews)
      .where(eq(portfolioViews.userId, userId));
    return result.count;
  }

  // Analytics
  async getUserStats(): Promise<{ total: number; students: number; faculty: number; recruiters: number; admins: number; }> {
    const [stats] = await db
      .select({
        total: count(),
        students: count(sql`CASE WHEN role = 'student' THEN 1 END`),
        faculty: count(sql`CASE WHEN role = 'faculty' THEN 1 END`),
        recruiters: count(sql`CASE WHEN role = 'recruiter' THEN 1 END`),
        admins: count(sql`CASE WHEN role = 'admin' THEN 1 END`),
      })
      .from(users);
    return stats;
  }

  async getCertificateStats(): Promise<{ total: number; pending: number; approved: number; rejected: number; }> {
    const [stats] = await db
      .select({
        total: count(),
        pending: count(sql`CASE WHEN status = 'pending' THEN 1 END`),
        approved: count(sql`CASE WHEN status = 'approved' THEN 1 END`),
        rejected: count(sql`CASE WHEN status = 'rejected' THEN 1 END`),
      })
      .from(certificates);
    return stats;
  }
}

export const storage = new DatabaseStorage();
