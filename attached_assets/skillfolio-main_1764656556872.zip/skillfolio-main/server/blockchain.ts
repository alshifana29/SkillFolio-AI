import crypto from 'crypto';
import { storage } from './storage';

export interface Block {
  blockNumber: number;
  hash: string;
  previousHash: string;
  data: string;
  timestamp: Date;
  nonce: number;
}

export class BlockchainService {
  async createBlock(data: string): Promise<Block> {
    const latestBlock = await storage.getLatestBlock();
    const blockNumber = latestBlock ? latestBlock.blockNumber + 1 : 1;
    const previousHash = latestBlock ? latestBlock.hash : '0';
    
    const block = {
      blockNumber,
      previousHash,
      data,
      timestamp: new Date(),
      nonce: 0,
    };

    // Simple proof of work - find hash with leading zeros
    let hash = '';
    while (!hash.startsWith('0000')) {
      block.nonce++;
      hash = this.calculateHash(block);
    }

    const finalBlock = { ...block, hash };
    await storage.addBlockchainRecord(finalBlock);
    
    return finalBlock;
  }

  async verifyBlock(hash: string): Promise<boolean> {
    const block = await storage.getBlockchainRecord(hash);
    if (!block) return false;

    // Verify hash
    const calculatedHash = this.calculateHash({
      blockNumber: block.blockNumber,
      previousHash: block.previousHash || '0',
      data: block.data,
      timestamp: block.timestamp,
      nonce: block.nonce,
    });

    return calculatedHash === block.hash;
  }

  private calculateHash(block: Omit<Block, 'hash'>): string {
    const blockString = JSON.stringify({
      blockNumber: block.blockNumber,
      previousHash: block.previousHash,
      data: block.data,
      timestamp: block.timestamp.toISOString(),
      nonce: block.nonce,
    });
    
    return crypto.createHash('sha256').update(blockString).digest('hex');
  }

  async addCertificateToBlockchain(certificateId: string, certificateData: any): Promise<string> {
    const data = JSON.stringify({
      certificateId,
      ...certificateData,
      timestamp: new Date().toISOString(),
    });

    const block = await this.createBlock(data);
    return block.hash;
  }
}

export const blockchainService = new BlockchainService();
