import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { blockchainService } from "./blockchain";
import { upload } from "./upload";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { insertUserSchema, loginSchema, insertCertificateSchema, Certificate } from "@shared/schema";
import { z } from "zod";
import path from "path";
import QRCode from "qrcode";
import express from "express";
import { users } from "@shared/schema";
import { db } from "./db";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Auth middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded: any = jwt.verify(token, JWT_SECRET);
    const user = await storage.getUser(decoded.userId);
    
    if (!user || !user.isActive) {
      return res.status(401).json({ message: 'Invalid or inactive user' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }
};

// Role-based middleware
const requireRole = (roles: string[]) => {
  return (req: any, res: any, next: any) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded files
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Registration failed' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(loginData.email);
      if (!user || !user.isActive) {
        return res.status(401).json({ message: 'Invalid credentials or inactive account' });
      }

      const isValidPassword = await bcrypt.compare(loginData.password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const { password, ...userWithoutPassword } = user;
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Login error:', error);
      res.status(500).json({ message: 'Login failed' });
    }
  });

  app.get('/api/auth/me', authenticateToken, async (req: any, res) => {
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });

  // Certificate routes
  app.post('/api/certificates', authenticateToken, upload.single('certificate'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Certificate file is required' });
      }

      const certificateData = insertCertificateSchema.parse(req.body);
      
      const certificate = await storage.createCertificate({
        userId: req.user.id,
        fileName: req.file.originalname,
        filePath: req.file.path,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        status: 'pending',
        reviewedBy: null,
        reviewNotes: null,
        blockchainHash: null,
        qrCode: null,
        
        title: certificateData.title,
        institution: certificateData.institution,
        description: certificateData.description ?? null,
      });

      res.json(certificate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Certificate upload error:', error);
      res.status(500).json({ message: 'Certificate upload failed' });
    }
  });

  app.get('/api/certificates', authenticateToken, async (req: any, res) => {
    try {
      let certificates;
      
      if (req.user.role === 'student') {
        certificates = await storage.getCertificatesByUser(req.user.id);
      } else if (req.user.role === 'faculty' || req.user.role === 'admin') {
        const status = req.query.status as string;
        if (status) {
          certificates = await storage.getCertificatesByStatus(status);
        } else {
          certificates = await storage.getCertificatesByStatus('pending');
        }
      } else {
        return res.status(403).json({ message: 'Access denied' });
      }

      res.json(certificates);
    } catch (error) {
      console.error('Get certificates error:', error);
      res.status(500).json({ message: 'Failed to retrieve certificates' });
    }
  });

  app.get('/api/certificates/:id', authenticateToken, async (req: any, res) => {
    try {
      const certificate = await storage.getCertificate(req.params.id);
      
      if (!certificate) {
        return res.status(404).json({ message: 'Certificate not found' });
      }

      // Check permissions
      if (req.user.role === 'student' && certificate.userId !== req.user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }

      res.json(certificate);
    } catch (error) {
      console.error('Get certificate error:', error);
      res.status(500).json({ message: 'Failed to retrieve certificate' });
    }
  });

  app.patch('/api/certificates/:id/review', authenticateToken, requireRole(['faculty', 'admin']), async (req: any, res) => {
    try {
      const { status, reviewNotes } = req.body;
      let reviewNotesForUpdate: string | null = null;
      if (typeof reviewNotes === 'string') {
        reviewNotesForUpdate = reviewNotes;
      }
      
      if (!['approved', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }

      const certificate = await storage.getCertificate(req.params.id);
      if (!certificate) {
        return res.status(404).json({ message: 'Certificate not found' });
      }

      let blockchainHash: string | null = null;
      let qrCode: string | null = null;

      if (status === 'approved') {
        // Add to blockchain
        blockchainHash = await blockchainService.addCertificateToBlockchain(certificate.id, {
          title: certificate.title,
          institution: certificate.institution,
          userId: certificate.userId,
          reviewedBy: req.user.id,
        });

        // Generate QR code
        const qrData = JSON.stringify({
          certificateId: certificate.id,
          blockchainHash,
          verificationUrl: `${req.protocol}://${req.get('host')}/api/verify/${blockchainHash}`,
        });
        qrCode = await QRCode.toDataURL(qrData);
      }

//       const updatedCertificate = await storage.updateCertificate(req.params.id, {
//   status: status as any,
//   reviewNotes: reviewNotes ?? null,
//   reviewedBy: req.user.id,
//   blockchainHash: blockchainHash ?? null,
//   qrCode: qrCode ?? null,
// });
  const updatedCertificate = await storage.updateCertificate(req.params.id, {
   status: status as any,
        reviewNotes: reviewNotesForUpdate,
        reviewedBy: req.user.id,
        blockchainHash: blockchainHash ?? null,
        qrCode: qrCode ?? null,
      } as Partial<Certificate>);


      res.json(updatedCertificate);
    } catch (error) {
      console.error('Certificate review error:', error);
      res.status(500).json({ message: 'Certificate review failed' });
    }
  });

  // Blockchain verification
  app.get('/api/verify/:hash', async (req, res) => {
    try {
      const isValid = await blockchainService.verifyBlock(req.params.hash);
      const blockData = await storage.getBlockchainRecord(req.params.hash);
      
      res.json({
        valid: isValid,
        block: blockData,
      });
    } catch (error) {
      console.error('Verification error:', error);
      res.status(500).json({ message: 'Verification failed' });
    }
  });

  // Portfolio routes
  app.get('/api/portfolio/:userId', async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const certificates = await storage.getCertificatesByUser(req.params.userId);
      const approvedCertificates = certificates.filter(cert => cert.status === 'approved');
      const viewCount = await storage.getPortfolioViews(req.params.userId);

      // Record portfolio view
      await storage.addPortfolioView({
        userId: req.params.userId,
        viewerIp: req.ip ?? null,
      });

      const { password, ...userWithoutPassword } = user;

      res.json({
        user: userWithoutPassword,
        certificates: approvedCertificates,
        viewCount: viewCount + 1,
      });
    } catch (error) {
      console.error('Portfolio error:', error);
      res.status(500).json({ message: 'Failed to load portfolio' });
    }
  });

  // Analytics routes
  app.get('/api/analytics/overview', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
      const userStats = await storage.getUserStats();
      const certificateStats = await storage.getCertificateStats();

      res.json({
        users: userStats,
        certificates: certificateStats,
      });
    } catch (error) {
      console.error('Analytics error:', error);
      res.status(500).json({ message: 'Failed to load analytics' });
    }
  });

  // User management routes
  app.get('/api/users', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
      // This would need pagination in a real app
      const usersData = await db.select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        role: users.role,
        isActive: users.isActive,
        createdAt: users.createdAt,
      }).from(users);

      res.json(usersData);
    } catch (error) {
      console.error('Get users error:', error);
      res.status(500).json({ message: 'Failed to retrieve users' });
    }
  });

  app.get('/api/students', authenticateToken, requireRole(['recruiter', 'admin']), async (req, res) => {
    try {
      const { keywords, field, year } = req.query;

      let students = await storage.getUsersByRole('student');

      if (keywords && typeof keywords === 'string' && keywords.trim() !== '') {
        const searchKeywords = keywords.trim().toLowerCase().split(/\s+/).filter(kw => kw);

        if (searchKeywords.length > 0) {
          const approvedCertificates = await storage.getCertificatesByStatus('approved');
          const certificatesByStudent: Record<string, Certificate[]> = {};
          for (const cert of approvedCertificates) {
            if (!certificatesByStudent[cert.userId]) {
              certificatesByStudent[cert.userId] = [];
            }
            certificatesByStudent[cert.userId].push(cert);
          }

          students = students.filter(student => {
            const studentText = `${student.firstName} ${student.lastName} ${student.email}`.toLowerCase();
            
            const studentCertificates = certificatesByStudent[student.id] || [];
            const certificatesText = studentCertificates
                .map(c => `${c.title} ${c.description || ''}`.toLowerCase())
                .join(' ');
                
            const fullText = `${studentText} ${certificatesText}`;

            return searchKeywords.every(kw => fullText.includes(kw));
          });
        }
      }

      // TODO: Implement filtering for field and year when data is available
      // For now, they don't do anything.

      const studentData = await Promise.all(students.map(async (student) => {
        // This part is inefficient, but let's stick to the existing pattern
        // to avoid breaking things. A better approach would be to get this
        // data in the initial filtered query.
        const certificates = await storage.getCertificatesByUser(student.id);
        const approvedCertificates = certificates.filter(c => c.status === 'approved');
        const portfolioViews = await storage.getPortfolioViews(student.id);

        const { password, ...studentWithoutPassword } = student;

        return {
          ...studentWithoutPassword,
          certificatesCount: approvedCertificates.length,
          portfolioViews: portfolioViews,
          status: 'available' as 'available' | 'seeking' | 'hired',
        };
      }));

      res.json(studentData);
    } catch (error) {
      console.error('Get students error:', error);
      res.status(500).json({ message: 'Failed to retrieve students' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
